from PIL import Image, ImageEnhance

# List of three insect images
insect_images = [
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG"
]

# List to store original + enhanced images
all_images = []

# Keep your original code intact for each insect
for img_path in insect_images:
    image = Image.open(img_path)
    sharpness_enhancer = ImageEnhance.Sharpness(image)
    enhanced_image = sharpness_enhancer.enhance(1.5)
    
    # Add to list (original first, then enhanced)
    all_images.extend([image, enhanced_image])

# Create grid (2 columns × 3 rows)
width, height = all_images[0].size
grid_width = width * 2
grid_height = height * 3
grid_image = Image.new('RGB', (grid_width, grid_height))

# Paste images into grid
for index, img in enumerate(all_images):
    row = index // 2
    col = index % 2
    grid_image.paste(img, (col * width, row * height))

# Show the final grid
grid_image.show()

# Optionally save it
grid_image.save(r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\Task5_Enhancement_Grid.png")