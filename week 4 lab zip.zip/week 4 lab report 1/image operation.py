from PIL import Image, ImageOps

# List of all three insect images (absolute paths)
insect_images = [
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG"
]

# Process each insect image with your exact original code
for img_path in insect_images:
    # create an image
    image = Image.open(img_path)
    
    # position changes
    image_mirror = ImageOps.mirror(image)
    # image_scale = ImageOps.scale(image, 0.5)
    
    # color changes
    image_inverted = ImageOps.invert(image_mirror.convert("RGB"))
    
    # add and remove
    image_border = ImageOps.expand(
        image=image_inverted,
        border=50,
        fill=(255,255,255)
    )
    # image_padded = ImageOps.pad(image, (4000,6000))
    # image_crop = ImageOps.crop(image = image, border = 200)
    
    # show final image
    image_border.show()