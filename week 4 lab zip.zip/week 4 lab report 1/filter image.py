from PIL import Image, ImageFilter

# List of 3 insect images
insect_images = [
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG"
]

# Processed images list
processed_images = []

for img_path in insect_images:
    image = Image.open(img_path)
    # apply filters
    image_boxblur = image.filter(ImageFilter.BoxBlur(radius=20))
    image_gaussianblur = image.filter(ImageFilter.GaussianBlur(radius=20))
    image_unsharp = image.filter(ImageFilter.UnsharpMask(radius=20))
    
    # add to list
    processed_images.extend([image_boxblur, image_gaussianblur, image_unsharp])

# Make a grid: 3 columns x 3 rows
width, height = processed_images[0].size
grid_width = width * 3
grid_height = height * 3

grid_image = Image.new('RGB', (grid_width, grid_height))

for index, img in enumerate(processed_images):
    row = index // 3
    col = index % 3
    grid_image.paste(img, (col * width, row * height))

# Show all 9 images at once as one big image
grid_image.show()

# Optionally save the grid image for report
grid_image.save(r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\All_9_Filters.png")