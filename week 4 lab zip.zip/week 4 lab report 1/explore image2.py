from PIL import Image

# Load the second insect image (absolute path)
image = Image.open(r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG")

print("Pixel at (0,0):", image.getpixel((0,0)))

red_grayscale_image = image.getchannel('R')
blue_grayscale_image = image.getchannel('B')

red_grayscale_image.show(title="Red Channel")
blue_grayscale_image.show(title="Blue Channel")

image.putpixel((0,0), (255,0,255))

for x in range(image.size[0]):
    for y in range(image.size[1]):
        if image.getpixel((x,y))[0] == 0:
            image.putpixel((x,y), (200,20,20))

image.show(title="Modified Image")