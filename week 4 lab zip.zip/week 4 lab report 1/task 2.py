from PIL import Image
insect_images = [
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG"
]

# Process each insect one by one
for idx, img_path in enumerate(insect_images, start=1):
    # Create an image via import
    image = Image.open(img_path)
    
    # Analyze the image (optional)
    # print(image.size)
    # print(image.filename)
    # print(image.format)
    
    # Flip the image (optional)
    # image = image.transpose(Image.Transpose.ROTATE_90)
    
    # Show original image (optional)
    # image.show()
    
    # Exercise: rotate 30 degrees
    img_rotated = image.rotate(30)
    
    # Save rotated image with a unique name
    save_path = rf"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\img_rotated_{idx}.png"
    img_rotated.save(save_path, 'PNG')
    
    # Show rotated image
    img_rotated.show()