from PIL import Image
insect_images = [
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG",
    r"C:\Users\BIKASH THAPA\OneDrive\文档\Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG"
]

for img_path in insect_images:
    image = Image.open(img_path)
    
    
    image_transpose = image.transpose(Image.Transpose.ROTATE_90)
    image_rotate = image.rotate(45, expand=False, center=(0,0))
    image_crop = image.crop((800,600,1600,1600))
    image_resize = image.resize((1000,600))
    combined_image = image.transpose(Image.Transpose.ROTATE_90).resize((2000,1500)).rotate(10)
    
    # Show the final manipulated image
    combined_image.show()