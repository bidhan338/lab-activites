from PIL import Image

# Load the insect image
image = Image.open(r"Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG")

# Get the color of the top-left pixel
print("Pixel at (0,0):", image.getpixel((0,0)))

# Create grayscale images for red and blue channels
red_grayscale_image = image.getchannel('R')
blue_grayscale_image = image.getchannel('B')

# Show red and blue grayscale images
red_grayscale_image.show(title="Red Channel")
blue_grayscale_image.show(title="Blue Channel")

# Change the top-left pixel to pink
image.putpixel((0,0), (255,0,255))

# Modify all pixels with red=0 to dark red
for x in range(image.size[0]):
    for y in range(image.size[1]):
        if image.getpixel((x,y))[0] == 0:
            image.putpixel((x,y), (200,20,20))

# Show the modified image
image.show(title="Modified Image")