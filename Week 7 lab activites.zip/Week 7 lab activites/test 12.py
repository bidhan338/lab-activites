
import os
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing import image
TEST_IMAGE_DIR = "/content/drive/MyDrive/ASSET/Insect_data set/test_data"
IMG_SIZE = (224, 224)
def load_and_preprocess_image(img_path, img_size=IMG_SIZE):
    img = image.load_img(img_path, target_size=img_size)
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array
# 4. Prediction Function
def predict_new_images(test_dir):
    img_files = [f for f in os.listdir(test_dir)
                 if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

    if not img_files:
        print("No images found in test_data folder")
        return

    plt.figure(figsize=(15, 5))

    for i, img_file in enumerate(img_files):
        path = os.path.join(test_dir, img_file)

        img_arr = load_and_preprocess_image(path)
        preds = model.predict(img_arr, verbose=0)

        pred_idx = np.argmax(preds[0])
        confidence = preds[0][pred_idx]

        img = image.load_img(path)

        plt.subplot(1, len(img_files), i+1)
        plt.imshow(img)
        plt.axis('off')
        plt.title(f"{class_names[pred_idx]}\n{confidence*100:.2f}%")

        print(f"{img_file} → {class_names[pred_idx]} ({confidence*100:.2f}%)")

    plt.tight_layout()
    plt.show()
print("Running inference...")
predict_new_images(TEST_IMAGE_DIR)