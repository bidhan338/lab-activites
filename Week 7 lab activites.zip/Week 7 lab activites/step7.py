val_loss, val_acc = model.evaluate(validation_dataset)
print(f'Validation accuracy: {val_acc*100:.2f}%')