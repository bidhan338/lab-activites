model.save('macroinvertebrates_classifier.h5')

print("Model saved as 'macroinvertebrates_classifier.h5'")