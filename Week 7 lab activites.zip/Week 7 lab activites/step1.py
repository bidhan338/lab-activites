import tensorflow as tf

# 1. Define the path to your training data
DATASET_DIR = '/content/drive/MyDrive/ASSET/Insect_data set/train_data'

# 2. Set the image size and batch size as per your PDF
IMG_SIZE = (224, 224)
BATCH_SIZE = 32

# 3. Load the training dataset
train_dataset = tf.keras.utils.image_dataset_from_directory(
    DATASET_DIR,
    validation_split=0.2,
    subset="training",
    seed=123,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE
)

# 4. Load the validation dataset
validation_dataset = tf.keras.utils.image_dataset_from_directory(
    DATASET_DIR,
    validation_split=0.2,
    subset="validation",
    seed=123,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE
)

# 5. Print the class names found
class_names = train_dataset.class_names
print(f"Species identified: {class_names}")